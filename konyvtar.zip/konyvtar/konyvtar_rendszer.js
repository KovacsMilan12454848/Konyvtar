var id = 4;

class Konyvek {
    constructor() {
        this.konyvek = [];
        this.kikolcsonzott = []
    }

    Hozzaadas(id, cim, ar, kep) {
        this.konyvek.push({ id, cim, ar, kep });
    }

    Card(szoveg, gombhatas, gombszin, kep, cim, ar, id, fo_div) {

        const div1 = document.createElement("div");
        const div2 = document.createElement("div");
        const div3 = document.createElement("div");
        const h5 = document.createElement("h5");
        const h6 = document.createElement("h6");
        const img = document.createElement("img");
        const button = document.createElement("button");

        div1.setAttribute("class", "col-md-4 col-lg-3 col-sm-6 col-xl-2  d-flex alma");
        div2.setAttribute("class", "card text-center w-100");
        div3.setAttribute("class", "card-body");
        h5.setAttribute("class", "card-title");
        h6.setAttribute("class", "card-text text-start");

        img.onerror = () => {
            img.onerror = null;
            img.setAttribute("src", "kepek/hiba.avif");
        };

        if (kep.length > 8 ) {
                img.setAttribute("src", kep);
        }
        else {
            img.setAttribute("src", "kepek/hiba.avif");
        }

        img.setAttribute("class", "card-img-top rounded mx-auto mt-3");
        img.setAttribute("style", "width: 85%");
        button.setAttribute("type", "button");
        button.setAttribute("class", `${gombszin} boost-btn`);
        button.setAttribute("onclick", gombhatas);
        button.setAttribute("id", id);

        h5.textContent = cim;
        h6.innerHTML = "id: " + id + "" + '<br>' + "Ár: " + ar;
        button.textContent = szoveg;

        div1.appendChild(div2);
        div2.appendChild(img);
        div2.appendChild(div3);
        div3.appendChild(h5);
        div3.appendChild(h6);
        div3.appendChild(button);
        fo_div.appendChild(div1);

    }

    kilistazas(szov, szin, hatas) {
        const fo_div = document.getElementById("oldal_adat");
        for (const i of this.konyvek) {
            this.Card(szov, hatas, szin, i.kep, i.cim, i.ar, i.id, fo_div);

        }
    }

    torles(adat, id) {
        const index = adat.findIndex(elem => elem.id === id);
        // const index = adat;
        console.log("index:", index);

        if (index !== -1) {
            adat.splice(index, 1);
            console.log("torolve");
        }
        else {
            console.log("id nem található ");
        }
    }

    FO_torles(id) {
        this.torles(this.konyvek, id);
    }

    Szerkeszt(id, cim, ar, kep) {
        const index = this.konyvek.findIndex(elem => elem.id === id);

        if (index !== -1) {
            this.konyvek[index].cim = cim;
            this.konyvek[index].ar = ar;
            this.konyvek[index].kep = kep
            console.log("Könyv módosítva:", this.konyvek[index]);
        } else {
            console.log("nincs könyv az id-val.");
        }
    }

    kolcsonzes(id, torol) {

        if (torol) {
            this.torles(this.kikolcsonzott, id);
        }
        else {
            this.kikolcsonzott.push({ id });
        }
    }

    kolcson_kiir() {

        var osszeg = 0;
        const fo_div = document.getElementById("oldal_adat");

        for (const i of this.konyvek) {
            for (const k of this.kikolcsonzott) {
                if (i.id == k.id) {
                    this.Card("Törlés", "torles(this)", "btn btn-outline-danger", i.kep, i.cim, i.ar, i.id, fo_div);
                    osszeg += parseInt(i.ar);
                }
            }
        }

        const hr = document.createElement("hr");
        const ar = document.createElement("h1");
        ar.setAttribute("class", "text-end")
        ar.textContent = "A végösszeg: " + osszeg;
        fo_div.appendChild(hr);
        fo_div.appendChild(ar);
    }
}
const konyv = new Konyvek();

konyv.Hozzaadas(1, "Harry Potter", 1450, "https://alexandra.hu/content/2024/4/Product/9789636144913.jpg");
konyv.Hozzaadas(2, "The Witcher", 2550, "https://filmtett.ro/resized/wp-content/uploads/2020/01/filmsidebar_witcher-poster.jpg");
konyv.Hozzaadas(3, "TÜNDÉRALKU", 2450, "https://alexandra.hu/content/2023/12/Product/9789635612017.jpg");

function Hozaad() {
    const cim = prompt("A könyv cime");
    const ar = parseInt(prompt("A könyv ara:"));
    const kep = prompt("A kép elérési utvonala (url)-ha nincs kép ne irj semmit!:")

    konyv.Hozzaadas(id, cim, ar, kep);
    id++;
    document.getElementById("oldal_adat").innerHTML = '';
    konyv.kilistazas("Törlés", "btn btn-outline-danger", "fo_torol(this)");
}

function kikolcsonzes(button) {
    const id = button.id;
    konyv.kolcsonzes(id, false);
}

function fo_torol(button) {
    const id = parseInt(button.id);
    konyv.FO_torles(id);

    document.getElementById("oldal_adat").innerHTML = '';
    konyv.kilistazas("Törlés", "btn btn-outline-danger", "fo_torol(this)");
}

function Szerkesztes_oldal() {
    document.getElementById("oldal_adat").innerHTML = '';
    konyv.kilistazas("Szerkesztes", "btn btn-outline-success", "Szerkeszt(this)");
}

function Szerkeszt(button) {
    const id = parseInt(button.id);
    const cim = prompt("ÚJ könyv cime");
    const ar = parseInt(prompt("ÚJ könyv ara:"));
    const kep = prompt("ÚJ kép elérési utvonala (url):")
    konyv.Szerkeszt(id, cim, ar, kep);

    Szerkesztes_oldal();
}

function torles(button) {
    const id = button.id;
    konyv.kolcsonzes(id, true);
    document.getElementById("oldal_adat").innerHTML = '';
    konyv.kolcson_kiir();
}

function alakitandok(nev) {
    document.getElementById("oldal_nev").textContent = nev;
    document.getElementById("oldal_adat").innerHTML = '';
    document.getElementById("gomb_div").innerHTML = '';
}

function konyvgomb(van, nev, szin, tipus) {
    const gomb_div = document.getElementById("gomb_div");
    const gomb = document.createElement("button");

    gomb.setAttribute("type", "button");
    gomb.setAttribute("class", szin);
    gomb.setAttribute("onclick", tipus);
    gomb.textContent = nev;

    gomb_div.appendChild(gomb);

    if (van) {
        const hr = document.createElement("hr");
        gomb_div.appendChild(hr);
    }
}

window.addEventListener('load', function () {
    konyv.kilistazas("Törlés", "btn btn-outline-danger", "fo_torol(this)");
});

function lap_1() {
    alakitandok("Könyvek felpakolása");
    konyvgomb(false, "Könyv Hozzáadása", "btn btn-info my-2 mx-3", "Hozaad()");
    konyvgomb(true, "Könyv Szerkesztése", "btn btn-success my-2 mx-3", "Szerkesztes_oldal()");

    konyv.kilistazas("Törlés", "btn btn-outline-danger", "fo_torol(this)");
}

function lap_2() {
    alakitandok("Könyv Kölcsönzés");
    konyv.kilistazas("kikölcsönzés", "btn btn-outline-info", "kikolcsonzes(this)");
}

function lap_3() {
    alakitandok("Kikölcsönzöttek");
    konyv.kolcson_kiir();
}